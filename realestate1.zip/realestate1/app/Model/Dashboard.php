<?php
class Dashboard extends AppModel
{
    
}
