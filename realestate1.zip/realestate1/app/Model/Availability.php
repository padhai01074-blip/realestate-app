<?php
class Availability extends AppModel
{
  public $useTable=false;
}
?>