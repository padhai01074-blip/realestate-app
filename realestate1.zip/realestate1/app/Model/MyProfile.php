<?php
class MyProfile extends AppModel
{
  public $useTable="clients";
}
?>