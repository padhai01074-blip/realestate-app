<?php
class Ourflat extends AppModel
{
    public $useTable='properties_flats';
    public $belongsTo=array('Unit');
}
