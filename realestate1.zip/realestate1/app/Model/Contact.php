<?php
class Contact extends AppModel
{
    public $useTable=false;
    
}
