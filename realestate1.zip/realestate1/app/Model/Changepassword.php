<?php
class Changepassword extends AppModel
{
  public $useTable="clients";
}
?>