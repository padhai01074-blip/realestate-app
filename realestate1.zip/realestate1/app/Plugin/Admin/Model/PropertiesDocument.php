<?php
class PropertiesDocument extends AppModel
{
  
}
?>