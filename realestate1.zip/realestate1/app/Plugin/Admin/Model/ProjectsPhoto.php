<?php
class ProjectsPhoto extends AppModel
{
  
}
?>