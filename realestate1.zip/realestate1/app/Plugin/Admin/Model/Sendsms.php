<?php
class Sendsms extends AppModel
{
  public $useTable=false;
}
?>