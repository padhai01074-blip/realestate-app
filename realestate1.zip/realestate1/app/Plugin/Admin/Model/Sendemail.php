<?php
class Sendemail extends AppModel
{
  public $useTable=false;
}
?>