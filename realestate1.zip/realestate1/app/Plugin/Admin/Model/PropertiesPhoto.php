<?php
class PropertiesPhoto extends AppModel
{
  
}
?>