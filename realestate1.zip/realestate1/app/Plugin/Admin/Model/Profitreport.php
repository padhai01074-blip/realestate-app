<?php
class Profitreport extends AppModel
{
    public $useTable = 'expenses_payments';
}
?>