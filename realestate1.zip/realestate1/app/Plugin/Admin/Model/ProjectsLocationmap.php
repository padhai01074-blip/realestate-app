<?php
class ProjectsLocationmap extends AppModel
{
  
}
?>