<?php
class HelpsController extends AdminAppController {
    public function index()
    {
        
    }    
}
