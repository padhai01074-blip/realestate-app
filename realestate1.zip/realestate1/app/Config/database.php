<?php
		class DATABASE_CONFIG {
		public $default = array(
			'datasource' => 'Database/Mysql',
			'persistent' => false,
			'host' => 'localhost',
			'login' => 'root',
			'password' => '',
			'database' => 'realestate',
			'prefix' => '',
			'encoding' => 'utf8',
		);	
		}
		?>